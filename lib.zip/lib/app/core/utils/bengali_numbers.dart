String toBengaliNumber(int number) {
  const digits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return number.toString().split('').map((char) {
    final value = int.tryParse(char);
    return value == null ? char : digits[value];
  }).join();
}

enum VisitStatus {
  pending,
  ongoing,
  completed,
  cancelled,
}

class FarmTask {
  final int id;

  final String farmName;
  final String ownerName;
  final String phone;

  final String village;

  final double latitude;
  final double longitude;

  final int cycleDay;

  final double distance;

  VisitStatus status;

  bool isSynced;

  final DateTime visitDate;

  FarmTask({
    required this.id,
    required this.farmName,
    required this.ownerName,
    required this.phone,
    required this.village,
    required this.latitude,
    required this.longitude,
    required this.cycleDay,
    required this.distance,
    required this.status,
    required this.isSynced,
    required this.visitDate,
  });

  bool get isCompleted => status == VisitStatus.completed;

  bool get isPending => status == VisitStatus.pending;

  bool get isOngoing => status == VisitStatus.ongoing;
}
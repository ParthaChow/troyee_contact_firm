import '../models/farm_task.dart';

class HomeRepository {
  List<FarmTask> getFarmTasks() {
    return [
      FarmTask(
        id: 1,
        farmName: 'করিম পোল্ট্রি ফার্ম',
        ownerName: 'করিম উদ্দিন',
        phone: '01711111111',
        village: 'সাহাপুর',
        latitude: 23.9001,
        longitude: 89.1220,
        cycleDay: 28,
        distance: 23,
        status: VisitStatus.pending,
        isSynced: false,
        visitDate: DateTime.now(),
      ),

      FarmTask(
        id: 2,
        farmName: 'রহিম ব্রয়লার ফার্ম',
        ownerName: 'রহিম শেখ',
        phone: '01811111111',
        village: 'চরপাড়া',
        latitude: 23.9140,
        longitude: 89.1550,
        cycleDay: 18,
        distance: 15,
        status: VisitStatus.pending,
        isSynced: false,
        visitDate: DateTime.now(),
      ),

      FarmTask(
        id: 3,
        farmName: 'সালাম লেয়ার ফার্ম',
        ownerName: 'সালাম মোল্লা',
        phone: '01911111111',
        village: 'বেলতলী',
        latitude: 23.9300,
        longitude: 89.1900,
        cycleDay: 22,
        distance: 9,
        status: VisitStatus.completed,
        isSynced: true,
        visitDate: DateTime.now(),
      ),
    ];
  }
}
import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../models/farm_task.dart';

class FarmTaskTile extends StatelessWidget {
  const FarmTaskTile({super.key, required this.task});

  final FarmTask task;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.cardWhite,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.iconBackground,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.egg_outlined,
              color: AppColors.accentOrange,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  task.name,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textDark,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'সাইকেল দিন ${task.cycleDay} - ${task.distance} কিমি দূরে',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textGrey,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: task.isCompleted
                  ? AppColors.completedBadge
                  : AppColors.pendingBadge,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              task.isCompleted ? 'সম্পন্ন' : 'বাকি আছে',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: task.isCompleted
                    ? AppColors.completedText
                    : AppColors.pendingText,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

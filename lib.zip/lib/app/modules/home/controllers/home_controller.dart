import 'package:get/get.dart';

import '../models/farm_task.dart';
import '../repositories/home_repository.dart';

enum FarmFilter {
  all,
  pending,
  completed,
}

class HomeController extends GetxController {
  HomeController();

  final HomeRepository _repository = HomeRepository();

  // Officer Information
  final officerName = 'রফিক';
  final zone = 'কুষ্টিয়া জোন';
  final statusLabel = 'সক্রিয়';

  // Dashboard
  final completedVisits = 0.obs;
  final totalVisits = 0.obs;
  final pendingSyncRecords = 52.obs;

  // Navigation
  final navIndex = 0.obs;

  // Search
  final searchText = ''.obs;

  // Filter
  final selectedFilter = FarmFilter.all.obs;

  // Data
  final farmTasks = <FarmTask>[].obs;

  // Visible List
  final filteredTasks = <FarmTask>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadFarmTasks();
  }

  void loadFarmTasks() {
    farmTasks.assignAll(_repository.getFarmTasks());

    applyFilter();
    updateDashboard();
  }

  void refreshData() {
    loadFarmTasks();
  }

  void updateDashboard() {
    completedVisits.value =
        farmTasks.where((e) => e.isCompleted).length;

    totalVisits.value = farmTasks.length;
  }

  int get remainingVisits =>
      totalVisits.value - completedVisits.value;

  double get progressValue {
    if (totalVisits.value == 0) return 0;

    return completedVisits.value / totalVisits.value;
  }

  void changeNavIndex(int index) {
    navIndex.value = index;
  }

  void search(String value) {
    searchText.value = value;
    applyFilter();
  }

  void changeFilter(FarmFilter filter) {
    selectedFilter.value = filter;
    applyFilter();
  }

  void applyFilter() {
    List<FarmTask> list = List.from(farmTasks);

    // Search
    if (searchText.value.isNotEmpty) {
      list = list.where((task) {
        return task.farmName
            .toLowerCase()
            .contains(searchText.value.toLowerCase()) ||
            task.ownerName
                .toLowerCase()
                .contains(searchText.value.toLowerCase()) ||
            task.village
                .toLowerCase()
                .contains(searchText.value.toLowerCase());
      }).toList();
    }

    // Filter
    switch (selectedFilter.value) {
      case FarmFilter.pending:
        list = list.where((e) => e.isPending).toList();
        break;

      case FarmFilter.completed:
        list = list.where((e) => e.isCompleted).toList();
        break;

      case FarmFilter.all:
        break;
    }

    filteredTasks.assignAll(list);
  }

  void completeVisit(int id) {
    final index = farmTasks.indexWhere((e) => e.id == id);

    if (index == -1) return;

    farmTasks[index].status = VisitStatus.completed;

    farmTasks.refresh();

    applyFilter();

    updateDashboard();
  }

  void startVisit(int id) {
    final index = farmTasks.indexWhere((e) => e.id == id);

    if (index == -1) return;

    farmTasks[index].status = VisitStatus.ongoing;

    farmTasks.refresh();

    applyFilter();
  }

  void syncRecord() {
    if (pendingSyncRecords.value > 0) {
      pendingSyncRecords.value--;
    }
  }
}